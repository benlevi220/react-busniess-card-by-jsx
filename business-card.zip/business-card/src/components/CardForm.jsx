/* eslint-disable no-unused-vars */
import styled from '@emotion/styled';
import UploadIcon from '@mui/icons-material/Upload';
import { Button, Grid, OutlinedInput, Stack, Typography } from '@mui/material';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import * as Yup from 'yup';

const CardForm = ({
  title,
  subTitle,
  image,
  phone,
  address,
  city,
  country,
  fullName,
  handleSubmit,
  email,
}) => {
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      title,
      subTitle,
      image,
      phone,
      address,
      city,
      country,
      fullName,
      attachment: null,
      email,
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .strict(true)
        .email('Invalid Email Address!')
        .required('Email Address is required!'),
      fullName: Yup.string().required('Full Name is required!'),
      title: Yup.string().required('Title is required!'),
      subTitle: Yup.string().required('Subtitle is required!'),
      image: Yup.string().required('Image is required!'),
      phone: Yup.string().required('Phone is required!'),
      address: Yup.string().required('Address is required!'),
      city: Yup.string().required('City is required!'),
      country: Yup.string().required('Country is required!'),
    }),
    onSubmit: (values) => {
      delete values.attachment;
      handleSubmit(values);
    },
  });

  const handleImageUpload = (e) => {
    const selectedFile = e.target.files;

    if (selectedFile.length > 0) {
      formik.setFieldValue('image', selectedFile[0]);
      formik.setFieldValue('image', URL.createObjectURL(selectedFile[0]));
    }
  };

  return (
    <form style={{ width: '100%' }} onSubmit={formik.handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Full Name
          </Typography>
          <OutlinedInput
            id='login-fullName'
            placeholder='Enter your full name here'
            fullWidth
            label=''
            name='fullName'
            value={formik.values.fullName}
            onChange={formik.handleChange}
            error={formik.touched.fullName && Boolean(formik.errors.fullName)}
          />
          {formik.touched.fullName && formik.errors.fullName && (
            <Typography variant='body2' color='error'>
              {formik.errors.fullName}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Email
          </Typography>
          <OutlinedInput
            id='login-email'
            placeholder='Enter your email here'
            type='email'
            fullWidth
            label=''
            name='email'
            value={formik.values.email}
            onChange={formik.handleChange}
            error={formik.touched.email && Boolean(formik.errors.email)}
          />
          {formik.touched.email && formik.errors.email && (
            <Typography variant='body2' color='error'>
              {formik.errors.email}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Title
          </Typography>
          <OutlinedInput
            id='login-title'
            placeholder='Enter card title here'
            fullWidth
            label=''
            name='title'
            value={formik.values.title}
            onChange={formik.handleChange}
            error={formik.touched.title && Boolean(formik.errors.title)}
          />
          {formik.touched.title && formik.errors.title && (
            <Typography variant='body2' color='error'>
              {formik.errors.title}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Subtitle
          </Typography>
          <OutlinedInput
            id='login-subTitle'
            placeholder='Enter card sub-title here'
            fullWidth
            label=''
            name='subTitle'
            value={formik.values.subTitle}
            onChange={formik.handleChange}
            error={formik.touched.subTitle && Boolean(formik.errors.subTitle)}
          />
          {formik.touched.subTitle && formik.errors.subTitle && (
            <Typography variant='body2' color='error'>
              {formik.errors.subTitle}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Phone No
          </Typography>
          <OutlinedInput
            id='login-phone'
            placeholder='Enter your phone no here'
            fullWidth
            label=''
            name='phone'
            value={formik.values.phone}
            onChange={formik.handleChange}
            error={formik.touched.phone && Boolean(formik.errors.phone)}
          />
          {formik.touched.phone && formik.errors.phone && (
            <Typography variant='body2' color='error'>
              {formik.errors.phone}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Address
          </Typography>
          <OutlinedInput
            id='login-address'
            placeholder='Enter your address here'
            fullWidth
            label=''
            name='address'
            value={formik.values.address}
            onChange={formik.handleChange}
            error={formik.touched.address && Boolean(formik.errors.address)}
          />
          {formik.touched.address && formik.errors.address && (
            <Typography variant='body2' color='error'>
              {formik.errors.address}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            City
          </Typography>
          <OutlinedInput
            id='login-city'
            placeholder='Enter your city here'
            fullWidth
            label=''
            name='city'
            value={formik.values.city}
            onChange={formik.handleChange}
            error={formik.touched.city && Boolean(formik.errors.city)}
          />
          {formik.touched.city && formik.errors.city && (
            <Typography variant='body2' color='error'>
              {formik.errors.city}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant='body2' gutterBottom>
            Country
          </Typography>
          <OutlinedInput
            id='login-country'
            placeholder='Enter your country here'
            fullWidth
            label=''
            name='country'
            value={formik.values.country}
            onChange={formik.handleChange}
            error={formik.touched.country && Boolean(formik.errors.country)}
          />
          {formik.touched.country && formik.errors.country && (
            <Typography variant='body2' color='error'>
              {formik.errors.country}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12}>
          <Typography variant='body2' gutterBottom>
            Card Image
          </Typography>
          <Stack
            direction='row'
            alignItems={'stretch'}
            spacing={1}
            width='100%'
          >
            <Button
              component='label'
              role={undefined}
              variant='contained'
              tabIndex={-1}
              startIcon={<UploadIcon />}
              sx={{ width: '170px' }}
            >
              Upload file
              <VisuallyHiddenInput type='file' onChange={handleImageUpload} />
            </Button>
            <OutlinedInput
              id='login-image'
              placeholder='image url'
              fullWidth
              label=''
              name='image'
              value={formik.values.image}
              readOnly
              error={formik.touched.image && Boolean(formik.errors.image)}
            />
          </Stack>
        </Grid>
      </Grid>
      <Stack
        mt={5}
        direction={'row'}
        spacing={1}
        alignItems={'center'}
        width='100%'
        maxWidth='400px'
        mx={'auto'}
      >
        <Button
          size='large'
          variant='contained'
          color='secondary'
          sx={{ flex: 1 }}
          onClick={() => navigate('/my-cards')}
        >
          Cancel
        </Button>
        <Button size='large' variant='contained' type='submit' sx={{ flex: 1 }}>
          Update Card
        </Button>
      </Stack>
    </form>
  );
};

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

CardForm.propTypes = {
  title: PropTypes.string,
  subTitle: PropTypes.string,
  image: PropTypes.string,
  phone: PropTypes.string,
  address: PropTypes.string,
  city: PropTypes.string,
  country: PropTypes.string,
  email: PropTypes.string,
  fullName: PropTypes.string,
  handleSubmit: PropTypes.func,
};

export default CardForm;
