import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import FavoriteIcon from '@mui/icons-material/Favorite';
import PhoneIcon from '@mui/icons-material/Phone';
import { Divider, IconButton, Stack } from '@mui/material';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';

const BusinessCard = ({
  id,
  title,
  subTitle,
  image,
  phone,
  address,
  cardNumber,
  isFav = true,
  isPrivate = false,
}) => {
  const navigate = useNavigate();

  return (
    <Card width='inherit'>
      <CardMedia sx={{ height: 250 }} image={image} title='green iguana' />
      <CardContent>
        <Stack spacing={1}>
          <section>
            <Typography gutterBottom variant='h5' component='div'>
              {title}
            </Typography>
            <Typography
              gutterBottom
              variant='subtitlle1'
              color='text.secondary'
            >
              {subTitle}
            </Typography>
          </section>
          <Divider />
          <section>
            <Stack direction='row' spacing={1}>
              <Typography variant='subtitle2'>Phone : </Typography>
              <Typography variant='body2' color='text.secondary'>
                {phone}
              </Typography>
            </Stack>
            <Stack mt={0.5} direction='row' spacing={1}>
              <Typography variant='subtitle2'>Address : </Typography>
              <Typography variant='body2' color='text.secondary'>
                {address}
              </Typography>
            </Stack>
            <Stack mt={0.5} direction='row' spacing={1}>
              <Typography variant='subtitle2'>Card Number : </Typography>
              <Typography variant='body2' color='text.secondary'>
                {cardNumber}
              </Typography>
            </Stack>
          </section>
        </Stack>
      </CardContent>
      <CardActions
        sx={{ justifyContent: !isPrivate ? 'end' : 'space-between' }}
      >
        {isPrivate && (
          <Stack direction={'row'} spacing={0.25}>
            <IconButton>
              <DeleteIcon />
            </IconButton>
            <IconButton
              onClick={() => {
                console.log('first', `my-cards/${id}`);
                navigate(`/my-cards/${id}`);
              }}
            >
              <EditIcon />
            </IconButton>
          </Stack>
        )}
        <Stack direction='row' spacing={0.25}>
          <IconButton>
            <PhoneIcon />
          </IconButton>
          <IconButton color={isFav ? 'error' : 'initial'}>
            <FavoriteIcon />
          </IconButton>
        </Stack>
      </CardActions>
    </Card>
  );
};
BusinessCard.propTypes = {
  id: PropTypes.string,
  title: PropTypes.string,
  subTitle: PropTypes.string,
  image: PropTypes.string,
  phone: PropTypes.string,
  address: PropTypes.string,
  cardNumber: PropTypes.string,
  isFav: PropTypes.bool,
  isPrivate: PropTypes.bool,
};

export default BusinessCard;
