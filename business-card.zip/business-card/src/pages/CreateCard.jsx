import { Stack, Typography } from '@mui/material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CardForm from 'src/components/CardForm';

const CreateCard = () => {
  const [state] = useState({
    title: '',
    subTitle: '',
    image: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    fullName: '',
  });

  const navigate = useNavigate();

  const handleCreateCard = (values) => {
    // call api to create a card
    console.log('values', values);
    navigate('/my-cards');
  };

  return (
    <Stack
      my={5}
      alignItems={'center'}
      mx='auto'
      width={'100%'}
      maxWidth='800px'
      bgcolor={'#fff'}
      p={'30px'}
    >
      <Typography variant='h5' mb={5}>
        Create Card
      </Typography>

      <CardForm
        title={state.title}
        subTitle={state.subTitle}
        image={state.image}
        phone={state.phone}
        address={state.address}
        city={state.city}
        country={state.country}
        fullName={state.fullName}
        email={state.email}
        handleSubmit={handleCreateCard}
      />
    </Stack>
  );
};

export default CreateCard;
