import { CircularProgress, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import CardForm from 'src/components/CardForm';

const EditCard = () => {
  const { id } = useParams();

  const [loading, setLoading] = useState(true);
  const [state, setState] = useState({
    title: '',
    subTitle: '',
    image: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    fullName: '',
  });

  const navigate = useNavigate();

  const handleUpdateCard = (values) => {
    // Updated values from form, call api to update card content
    console.log('values', values);
    navigate('/my-cards');
  };

  useEffect(() => {
    setLoading(true);
    // Fetch daat of card using id then update state with api info

    setState({
      title: 'Business Card 1',
      subTitle: 'This is Sub heading of business card 1',
      image: '',
      phone: '1231232111',
      address: 'St#12, area abc',
      city: 'xyz',
      country: 'efg',
      fullName: 'user1',
      email: 'user@mail.co',
    });
    setLoading(false);
  }, [id]);

  return (
    <Stack
      my={5}
      alignItems={'center'}
      mx='auto'
      width={'100%'}
      maxWidth='800px'
      bgcolor={'#fff'}
      p={'30px'}
    >
      <Typography variant='h5' mb={5}>
        Edit Card
      </Typography>
      {loading ? (
        <Stack
          alignItems={'center'}
          justifyContent={'center'}
          height='300px'
          width='100%'
        >
          <CircularProgress size={'2rem'} />
        </Stack>
      ) : (
        <CardForm
          title={state.title}
          subTitle={state.subTitle}
          image={state.image}
          phone={state.phone}
          address={state.address}
          city={state.city}
          country={state.country}
          fullName={state.fullName}
          email={state.email}
          handleSubmit={handleUpdateCard}
        />
      )}
    </Stack>
  );
};

export default EditCard;
