import { Stack, Typography } from '@mui/material';
import cardBg from 'src/assets/cardBg.png';
import BusinessCard from 'src/components/BusinessCard';
import { GridContainer } from 'src/utils/globalStyles';

const MyFavorites = () => {
  return (
    <Stack my={3} spacing={3}>
      <section>
        <Typography variant='h2'>My Favourites</Typography>
      </section>
      <GridContainer>
        {[...Array(2)].map((_, index) => (
          <BusinessCard
            key={index}
            id={index}
            title={`Business Card ${index + 1}`}
            subTitle={`This is subheading of business ${index + 1}`}
            phone={'+91 9876543210'}
            address={`Address 123, City#${index + 1}22,`}
            cardNumber={`457328${index + 1}`}
            image={cardBg}
          />
        ))}
      </GridContainer>
    </Stack>
  );
};

export default MyFavorites;
