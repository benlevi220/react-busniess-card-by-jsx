import { Stack, Typography } from '@mui/material';
import cardBg from 'src/assets/cardBg.png';
import BusinessCard from 'src/components/BusinessCard';
import { GridContainer } from 'src/utils/globalStyles';

const Home = () => {
  return (
    <Stack my={3} spacing={3}>
      <section>
        <Typography variant='h2'>Business Cards</Typography>
        <Typography variant='h5' sx={{ fontWeight: 500 }}>
          Here you can find all business cards
        </Typography>
      </section>
      <GridContainer>
        {[...Array(4)].map((_, index) => (
          <BusinessCard
            id={index}
            key={index}
            title={`Business Card ${index + 1}`}
            subTitle={`This is subheading of business ${index + 1}`}
            phone={'+91 9876543210'}
            address={`Address 123, City#${index + 1}22,`}
            cardNumber={`457328${index + 1}`}
            image={cardBg}
          />
        ))}
      </GridContainer>
    </Stack>
  );
};

export default Home;
