import { Button, Stack, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import cardBg from 'src/assets/cardBg.png';
import BusinessCard from 'src/components/BusinessCard';
import { GridContainer } from 'src/utils/globalStyles';

const MyCards = () => {
  const navigate = useNavigate();

  return (
    <Stack my={3} spacing={3}>
      <Stack
        direction={'row'}
        alignItems={'center'}
        justifyContent={'space-between'}
      >
        <Typography variant='h2'>My Cards</Typography>
        <Button
          variant='contained'
          onClick={() => navigate('/my-cards/create')}
        >
          Add New Card
        </Button>
      </Stack>
      <GridContainer>
        {[...Array(1)].map((_, index) => (
          <BusinessCard
            key={index}
            id={index + 1}
            title={`Business Card ${index + 1}`}
            subTitle={`This is subheading of business ${index + 1}`}
            phone={'+91 9876543210'}
            address={`Address 123, City#${index + 1}22,`}
            cardNumber={`457328${index + 1}`}
            image={cardBg}
            isPrivate={true}
          />
        ))}
      </GridContainer>
    </Stack>
  );
};

export default MyCards;
