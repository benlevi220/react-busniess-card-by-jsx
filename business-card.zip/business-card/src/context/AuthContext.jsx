/* eslint-disable react-refresh/only-export-components */
import PropTypes from 'prop-types';
import { createContext, useContext, useState } from 'react';

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [state, setState] = useState({
    isLoggedIn: true,
  });

  const handleLogin = () => setState({ isLoggedIn: true });
  const handleLogout = () => setState({ isLoggedIn: false });

  return (
    <AuthContext.Provider
      displayName='Auth Context'
      value={{
        isLoggedIn: state.isLoggedIn,
        handleLogin,
        handleLogout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

AuthProvider.propTypes = {
  children: PropTypes.node,
};

const useAuth = () => useContext(AuthContext);
export { AuthProvider, useAuth };
