export const NavItems = [
  {
    label: 'My Cards',
    url: '/my-cards',
  },
  {
    label: 'My Favourites',
    url: '/my-favorites',
  },
];

export const Account = [{ label: 'Profile', url: '/profile' }];
