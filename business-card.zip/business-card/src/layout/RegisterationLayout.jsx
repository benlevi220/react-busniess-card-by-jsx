import { Stack } from '@mui/material';
import { Outlet } from 'react-router-dom';

const RegisterationLayout = () => {
  return (
    <Stack
      alignItems={'center'}
      justifyContent={'center'}
      width='inherit'
      height='inherit'
    >
      <Outlet />
    </Stack>
  );
};

export default RegisterationLayout;
